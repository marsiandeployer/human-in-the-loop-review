=== SimpleReview — AI Code Review for Websites ===
Contributors:      noxondigital
Tags:              ai, code review, element inspector, website feedback, developer tools
Requires at least: 5.9
Tested up to:      6.9
Requires PHP:      7.4
Stable tag:        1.0.0
License:           GPLv2 or later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Hover over any element on your site, instantly copy its debug report — HTML, DOM path, screenshot — and pass it to any AI coding agent. Free to use.

== Description ==

SimpleReview adds a visual element inspector to your WordPress site. Hover over any element and click **Copy** to get a ready-made debug report — element HTML, DOM path, CSS selector, viewport size, and a screenshot — all in one block. Paste it straight into Claude, ChatGPT, Copilot, or any other AI coding agent and get an instant fix. Free, no account required for the copy feature.

Want to go further? Click **Fix it** to open a built-in AI chat panel (powered by Claude or Codex) pre-filled with the element context — so you can iterate on fixes without leaving the page.

**How it works**

1. Click **AI Review** in the admin bar to activate the inspector.
2. Hover over any element on the page — it highlights in orange.
3. Click the element, then click **Fix it** in the popup.
4. A side panel opens with an AI assistant pre-filled with the element's HTML, CSS path, and a screenshot.
5. The AI generates a fix, patch, or full PR description.

**Roles supported**

Administrators and Editors can use the inspector by default. The allowed roles can be configured in *Settings → SimpleReview*.

**External services**

This plugin sends data to an external AI webchat service so you can get code fixes. By default the configured URL points to `https://simpledashboard.wpmix.net/terminal/?product=simple_review` (operated by Noxon Digital). When you click **Fix it**, the following information is transmitted to that URL: element HTML snippet, CSS/DOM path, page URL, viewport size, a screenshot of the selected element, and your note. Nothing is sent for visitors, or for logged-in users who never click the button.

You can change the target URL in *Settings → SimpleReview* to point at your own self-hosted AI agent, so no data leaves your infrastructure.

- Service: Noxon Digital SimpleReview Webchat
- Terms of Service: https://onout.org/simpledashboard/privacy/
- Privacy Policy: https://onout.org/simpledashboard/privacy/

== Installation ==

1. Upload the `simple-review` folder to `/wp-content/plugins/`.
2. Activate the plugin in *Plugins → Installed Plugins*.
3. Go to *Settings → SimpleReview* to configure the webchat URL and allowed roles.
4. Visit any page on your site — the **AI Review** button appears in the admin bar.

== Frequently Asked Questions ==

= Does this work without a SimpleReview account? =

You need a SimpleReview account (free tier available) to use the AI chat. Visit [simpledashboard.wpmix.net](https://simpledashboard.wpmix.net/terminal/?product=simple_review) to sign in.

= Can visitors use the inspector? =

No. The inspector is only shown to logged-in users whose role is in the allowed-roles list. Visitors never see the button or the panel.

= Does the plugin slow down my site? =

The scripts are only loaded for logged-in users with the correct role. Public visitors are completely unaffected.

= Can I use my own AI backend? =

Yes — configure any webchat URL in *Settings → SimpleReview*.

== Changelog ==

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.0 =
Initial release — no upgrade needed.
