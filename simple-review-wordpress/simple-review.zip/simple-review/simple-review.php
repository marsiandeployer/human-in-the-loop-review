<?php
/**
 * Plugin Name:       SimpleReview — AI Code Review for Websites
 * Plugin URI:        https://onout.org/vibers/simple-review/
 * Description:       Hover any element, copy its debug report (HTML, DOM path, screenshot) and paste into any AI coding agent — free. Or click Fix it for a built-in Claude/Codex chat.
 * Version:           1.0.0
 * Requires at least: 5.9
 * Requires PHP:      7.4
 * Author:            Noxon Digital
 * Author URI:        https://onout.org/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       simple-review
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SIMPLE_REVIEW_VERSION', '1.0.0' );
define( 'SIMPLE_REVIEW_DIR', plugin_dir_path( __FILE__ ) );
define( 'SIMPLE_REVIEW_URL', plugin_dir_url( __FILE__ ) );

// --- Default settings ---
function simple_review_defaults() {
    return [
        'webchat_url'   => 'https://simpledashboard.wpmix.net/terminal/?product=simple_review',
        'enabled_roles' => [ 'administrator', 'editor' ],
        'show_on_front' => true,
    ];
}

function simple_review_get( $key ) {
    $opts = get_option( 'simple_review_settings', [] );
    $defs = simple_review_defaults();
    return array_key_exists( $key, $opts ) ? $opts[ $key ] : ( $defs[ $key ] ?? null );
}

// --- Check if current user can use SimpleReview ---
function simple_review_user_can() {
    if ( ! is_user_logged_in() ) return false;
    $allowed = (array) simple_review_get( 'enabled_roles' );
    $user    = wp_get_current_user();
    return (bool) array_intersect( $allowed, (array) $user->roles );
}

// --- Enqueue assets on frontend ---
add_action( 'wp_enqueue_scripts', function () {
    if ( ! simple_review_user_can() ) return;
    if ( ! simple_review_get( 'show_on_front' ) ) return;

    simple_review_enqueue();
} );

// --- Enqueue assets in admin ---
add_action( 'admin_enqueue_scripts', function () {
    if ( ! simple_review_user_can() ) return;

    simple_review_enqueue();
} );

function simple_review_enqueue() {
    wp_enqueue_script(
        'simple-review-html2image',
        SIMPLE_REVIEW_URL . 'assets/js/html-to-image.js',
        [],
        SIMPLE_REVIEW_VERSION,
        false
    );

    wp_enqueue_script(
        'simple-review-embed',
        SIMPLE_REVIEW_URL . 'assets/js/embed.js',
        [ 'simple-review-html2image' ],
        SIMPLE_REVIEW_VERSION,
        false
    );

    wp_enqueue_script(
        'simple-review-panel',
        SIMPLE_REVIEW_URL . 'assets/js/simple-review-panel.js',
        [ 'simple-review-embed' ],
        SIMPLE_REVIEW_VERSION,
        true
    );

    wp_localize_script( 'simple-review-panel', 'SimpleReviewConfig', [
        'webchatUrl' => esc_url( simple_review_get( 'webchat_url' ) ),
        'nonce'      => wp_create_nonce( 'simple_review' ),
        'version'    => SIMPLE_REVIEW_VERSION,
    ] );

    wp_enqueue_style(
        'simple-review',
        SIMPLE_REVIEW_URL . 'assets/css/simple-review.css',
        [],
        SIMPLE_REVIEW_VERSION
    );
}

// --- Admin bar button ---
add_action( 'admin_bar_menu', function ( WP_Admin_Bar $bar ) {
    if ( ! simple_review_user_can() ) return;
    if ( ! is_admin_bar_showing() ) return;

    $bar->add_node( [
        'id'    => 'simple-review-toggle',
        'title' => '<img src="' . esc_url( SIMPLE_REVIEW_URL . 'assets/icons/icon16.png' ) . '" width="16" height="16" style="vertical-align:middle;margin-right:5px;position:relative;top:-1px;"> AI Review',
        'href'  => '#',
        'meta'  => [
            'title'   => 'Toggle SimpleReview element inspector',
            'onclick' => 'return SimpleReview.toggle();',
            'class'   => 'simple-review-adminbar-btn',
        ],
    ] );
}, 100 );

// --- Settings page ---
add_action( 'admin_menu', function () {
    add_options_page(
        'SimpleReview Settings',
        'SimpleReview',
        'manage_options',
        'simple-review',
        'simple_review_settings_page'
    );
} );

add_action( 'admin_init', function () {
    register_setting( 'simple_review_group', 'simple_review_settings', [
        'sanitize_callback' => 'simple_review_sanitize_settings',
    ] );
} );

function simple_review_sanitize_settings( $input ) {
    $clean = [];
    $clean['webchat_url']   = esc_url_raw( $input['webchat_url'] ?? '' );
    $clean['show_on_front'] = ! empty( $input['show_on_front'] );

    $all_roles = array_keys( wp_roles()->roles );
    $clean['enabled_roles'] = [];
    if ( ! empty( $input['enabled_roles'] ) ) {
        foreach ( (array) $input['enabled_roles'] as $role ) {
            if ( in_array( $role, $all_roles, true ) ) {
                $clean['enabled_roles'][] = $role;
            }
        }
    }
    if ( empty( $clean['enabled_roles'] ) ) {
        $clean['enabled_roles'] = [ 'administrator' ];
    }
    return $clean;
}

function simple_review_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) return;
    $opts = get_option( 'simple_review_settings', simple_review_defaults() );
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'SimpleReview Settings', 'simple-review' ); ?></h1>
        <form method="post" action="options.php">
            <?php settings_fields( 'simple_review_group' ); ?>
            <table class="form-table">
                <tr>
                    <th><?php esc_html_e( 'Webchat URL', 'simple-review' ); ?></th>
                    <td>
                        <input type="url" name="simple_review_settings[webchat_url]"
                               value="<?php echo esc_attr( $opts['webchat_url'] ?? '' ); ?>"
                               class="regular-text" />
                        <p class="description"><?php esc_html_e( 'URL of the SimpleReview AI webchat (including ?product=simple_review).', 'simple-review' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Show on Frontend', 'simple-review' ); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="simple_review_settings[show_on_front]" value="1"
                                <?php checked( ! empty( $opts['show_on_front'] ) ); ?> />
                            <?php esc_html_e( 'Enable the inspector on public-facing pages', 'simple-review' ); ?>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Allowed Roles', 'simple-review' ); ?></th>
                    <td>
                        <?php
                        $enabled = (array) ( $opts['enabled_roles'] ?? [ 'administrator' ] );
                        foreach ( wp_roles()->roles as $slug => $role ) :
                            ?>
                            <label style="display:block;margin-bottom:4px;">
                                <input type="checkbox"
                                       name="simple_review_settings[enabled_roles][]"
                                       value="<?php echo esc_attr( $slug ); ?>"
                                    <?php checked( in_array( $slug, $enabled, true ) ); ?> />
                                <?php echo esc_html( translate_user_role( $role['name'] ) ); ?>
                            </label>
                        <?php endforeach; ?>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// --- Activation ---
register_activation_hook( __FILE__, function () {
    if ( false === get_option( 'simple_review_settings' ) ) {
        add_option( 'simple_review_settings', simple_review_defaults() );
    }
} );
