/**
 * SimpleReview WordPress panel — replaces Chrome extension side panel.
 * No chrome.* APIs — uses localStorage + floating div overlay.
 */
;(function () {
  'use strict';

  var cfg = window.SimpleReviewConfig || {};
  var WEBCHAT_URL = String(cfg.webchatUrl || 'https://simpledashboard.wpmix.net/terminal/?product=simple_review');

  // ---- Panel DOM ----
  var panel, iframe, closeBtn, header;

  function buildPanel() {
    if (panel) return;

    panel = document.createElement('div');
    panel.id = 'sr-panel';
    panel.innerHTML = [
      '<div id="sr-panel-header">',
        '<span id="sr-panel-title">SimpleReview</span>',
        '<button id="sr-panel-close" title="Close">&times;</button>',
      '</div>',
      '<div id="sr-panel-body">',
        '<iframe id="sr-panel-iframe" allow="clipboard-write" sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-top-navigation-by-user-activation"></iframe>',
      '</div>',
    ].join('');

    document.body.appendChild(panel);

    iframe   = document.getElementById('sr-panel-iframe');
    closeBtn = document.getElementById('sr-panel-close');
    header   = document.getElementById('sr-panel-header');

    closeBtn.addEventListener('click', hidePanel);

    // Drag header to resize/move (simple drag-from-header)
    var dragging = false, startX, startW;
    header.addEventListener('mousedown', function (e) {
      dragging = true;
      startX   = e.clientX;
      startW   = panel.offsetWidth;
    });
    document.addEventListener('mousemove', function (e) {
      if (!dragging) return;
      var diff = startX - e.clientX;
      var w = Math.min(800, Math.max(320, startW + diff));
      panel.style.width = w + 'px';
    });
    document.addEventListener('mouseup', function () { dragging = false; });

    // Listen for postMessages from the webchat iframe
    window.addEventListener('message', onIframeMessage);
  }

  function showPanel(url) {
    buildPanel();
    panel.classList.add('sr-open');
    iframe.src = url || normalizeUrl(WEBCHAT_URL);
  }

  function hidePanel() {
    if (panel) panel.classList.remove('sr-open');
  }

  // ---- JWT helpers ----
  function jwtExpired(jwt) {
    try {
      var p = JSON.parse(atob(jwt.split('.')[1]));
      return !p.exp || (Date.now() / 1000) > p.exp - 60;
    } catch (_) { return true; }
  }

  function getAuth() {
    try {
      var raw = localStorage.getItem('sr_auth');
      return raw ? JSON.parse(raw) : null;
    } catch (_) { return null; }
  }

  function saveAuth(data) {
    try { localStorage.setItem('sr_auth', JSON.stringify(data)); } catch (_) {}
  }

  function clearAuth() {
    try { localStorage.removeItem('sr_auth'); } catch (_) {}
  }

  // ---- URL helpers ----
  function normalizeUrl(raw) {
    try {
      var u = new URL(String(raw || '').trim());
      if (!u.searchParams.has('lang')) {
        u.searchParams.set('lang', /^ru\b/i.test(navigator.language || '') ? 'ru' : 'en');
      }
      return u.toString();
    } catch (_) { return raw; }
  }

  function buildChatUrl(prompt, agent) {
    var auth = getAuth();
    var base;
    if (auth && auth.jwt && auth.hostname && !jwtExpired(auth.jwt)) {
      base = new URL('https://' + auth.hostname + '/terminal/');
      base.searchParams.set('auth_jwt', auth.jwt);
    } else {
      base = new URL(normalizeUrl(WEBCHAT_URL));
    }
    if (prompt) base.searchParams.set('prompt', prompt.slice(0, 8000));
    if (agent)  base.searchParams.set('agent', agent);
    base.searchParams.set('site', window.location.href);
    return base.toString();
  }

  // ---- Messages from iframe ----
  function onIframeMessage(e) {
    var data = e && e.data;
    if (!data || typeof data !== 'object') return;

    // Persist JWT when authenticated
    if (data.type === 'sr_authed' && data.jwt && data.hostname) {
      saveAuth({ jwt: data.jwt, hostname: data.hostname, savedAt: Date.now() });
      return;
    }
    if (data.type === 'sr_logout') {
      clearAuth();
      if (iframe) iframe.src = normalizeUrl(WEBCHAT_URL);
      return;
    }
  }

  // ---- Intercept embed.js terminal panel ----
  // embed.js creates <div data-dev-inspect="terminal-panel"> with child <iframe>
  // We intercept it and redirect to our floating panel instead.
  var bridgeObserver = null;

  function startBridge() {
    if (bridgeObserver) return;
    bridgeObserver = new MutationObserver(function (mutations) {
      for (var i = 0; i < mutations.length; i++) {
        var added = mutations[i].addedNodes;
        for (var j = 0; j < added.length; j++) {
          var node = added[j];
          if (!node || node.nodeType !== 1) continue;
          if (!node.getAttribute || node.getAttribute('data-dev-inspect') !== 'terminal-panel') continue;

          var ifrm = node.querySelector('iframe');
          var promptUrl = '';
          try { promptUrl = (ifrm && (ifrm.src || ifrm.getAttribute('src'))) || ''; } catch (_) {}

          // Remove the inline panel
          node.remove();

          if (!promptUrl) { showPanel(null); continue; }

          try {
            var u = new URL(promptUrl);
            var prompt = u.searchParams.get('prompt') || '';
            var agent  = u.searchParams.get('agent')  || 'codex';
            showPanel(buildChatUrl(prompt, agent));
          } catch (_) {
            showPanel(null);
          }
        }
      }
    });

    if (document.body) {
      bridgeObserver.observe(document.body, { childList: true });
    } else {
      document.addEventListener('DOMContentLoaded', function () {
        bridgeObserver.observe(document.body, { childList: true });
      });
    }
  }

  // ---- Public API ----
  window.SimpleReview = {
    enable: function () {
      startBridge();
      if (window.DevInspect) window.DevInspect.enable();
      return false; // prevent href navigation
    },
    disable: function () {
      if (window.DevInspect) window.DevInspect.disable();
      hidePanel();
      return false;
    },
    toggle: function () {
      if (window.DevInspect && window.DevInspect.isActive && window.DevInspect.isActive()) {
        return SimpleReview.disable();
      }
      return SimpleReview.enable();
    },
    openPanel: function (prompt, agent) {
      startBridge();
      showPanel(buildChatUrl(prompt || '', agent || ''));
      return false;
    },
  };

  // Start bridge immediately so any early fix-it clicks work
  startBridge();

})();
