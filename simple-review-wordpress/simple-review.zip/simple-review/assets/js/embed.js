!function(t,e){"object"==typeof exports&&"undefined"!=typeof module?e(exports):"function"==typeof define&&define.amd?define(["exports"],e):e((t="undefined"!=typeof globalThis?globalThis:t||self).htmlToImage={})}(this,(function(t){"use strict";function e(t,e,n,r){return new(n||(n=Promise))((function(i,o){function u(t){try{a(r.next(t))}catch(t){o(t)}}function c(t){try{a(r.throw(t))}catch(t){o(t)}}function a(t){var e;t.done?i(t.value):(e=t.value,e instanceof n?e:new n((function(t){t(e)}))).then(u,c)}a((r=r.apply(t,e||[])).next())}))}function n(t,e){var n,r,i,o,u={label:0,sent:function(){if(1&i[0])throw i[1];return i[1]},trys:[],ops:[]};return o={next:c(0),throw:c(1),return:c(2)},"function"==typeof Symbol&&(o[Symbol.iterator]=function(){return this}),o;function c(c){return function(a){return function(c){if(n)throw new TypeError("Generator is already executing.");for(;o&&(o=0,c[0]&&(u=0)),u;)try{if(n=1,r&&(i=2&c[0]?r.return:c[0]?r.throw||((i=r.return)&&i.call(r),0):r.next)&&!(i=i.call(r,c[1])).done)return i;switch(r=0,i&&(c=[2&c[0],i.value]),c[0]){case 0:case 1:i=c;break;case 4:return u.label++,{value:c[1],done:!1};case 5:u.label++,r=c[1],c=[0];continue;case 7:c=u.ops.pop(),u.trys.pop();continue;default:if(!(i=u.trys,(i=i.length>0&&i[i.length-1])||6!==c[0]&&2!==c[0])){u=0;continue}if(3===c[0]&&(!i||c[1]>i[0]&&c[1]<i[3])){u.label=c[1];break}if(6===c[0]&&u.label<i[1]){u.label=i[1],i=c;break}if(i&&u.label<i[2]){u.label=i[2],u.ops.push(c);break}i[2]&&u.ops.pop(),u.trys.pop();continue}c=e.call(t,u)}catch(t){c=[6,t],r=0}finally{n=i=0}if(5&c[0])throw c[1];return{value:c[0]?c[1]:void 0,done:!0}}([c,a])}}}var r,i=(r=0,function(){return r+=1,"u".concat("0000".concat((Math.random()*Math.pow(36,4)<<0).toString(36)).slice(-4)).concat(r)});function o(t){for(var e=[],n=0,r=t.length;n<r;n++)e.push(t[n]);return e}var u=null;function c(t){return void 0===t&&(t={}),u||(u=t.includeStyleProperties?t.includeStyleProperties:o(window.getComputedStyle(document.documentElement)))}function a(t,e){var n=(t.ownerDocument.defaultView||window).getComputedStyle(t).getPropertyValue(e);return n?parseFloat(n.replace("px","")):0}function s(t,e){void 0===e&&(e={});var n,r,i,o=e.width||(r=a(n=t,"border-left-width"),i=a(n,"border-right-width"),n.clientWidth+r+i),u=e.height||function(t){var e=a(t,"border-top-width"),n=a(t,"border-bottom-width");return t.clientHeight+e+n}(t);return{width:o,height:u}}var l=16384;function f(t,e){return void 0===e&&(e={}),t.toBlob?new Promise((function(n){t.toBlob(n,e.type?e.type:"image/png",e.quality?e.quality:1)})):new Promise((function(n){for(var r=window.atob(t.toDataURL(e.type?e.type:void 0,e.quality?e.quality:void 0).split(",")[1]),i=r.length,o=new Uint8Array(i),u=0;u<i;u+=1)o[u]=r.charCodeAt(u);n(new Blob([o],{type:e.type?e.type:"image/png"}))}))}function h(t){return new Promise((function(e,n){var r=new Image;r.onload=function(){r.decode().then((function(){requestAnimationFrame((function(){return e(r)}))}))},r.onerror=n,r.crossOrigin="anonymous",r.decoding="async",r.src=t}))}function d(t){return e(this,void 0,void 0,(function(){return n(this,(function(e){return[2,Promise.resolve().then((function(){return(new XMLSerializer).serializeToString(t)})).then(encodeURIComponent).then((function(t){return"data:image/svg+xml;charset=utf-8,".concat(t)}))]}))}))}function v(t,r,i){return e(this,void 0,void 0,(function(){var e,o,u;return n(this,(function(n){return e="http://www.w3.org/2000/svg",o=document.createElementNS(e,"svg"),u=document.createElementNS(e,"foreignObject"),o.setAttribute("width","".concat(r)),o.setAttribute("height","".concat(i)),o.setAttribute("viewBox","0 0 ".concat(r," ").concat(i)),u.setAttribute("width","100%"),u.setAttribute("height","100%"),u.setAttribute("x","0"),u.setAttribute("y","0"),u.setAttribute("externalResourcesRequired","true"),o.appendChild(u),u.appendChild(t),[2,d(o)]}))}))}var p=function(t,e){if(t instanceof e)return!0;var n=Object.getPrototypeOf(t);return null!==n&&(n.constructor.name===e.name||p(n,e))};function g(t,e,n,r){var i=".".concat(t,":").concat(e),o=n.cssText?function(t){var e=t.getPropertyValue("content");return"".concat(t.cssText," content: '").concat(e.replace(/'|"/g,""),"';")}(n):function(t,e){return c(e).map((function(e){var n=t.getPropertyValue(e),r=t.getPropertyPriority(e);return"".concat(e,": ").concat(n).concat(r?" !important":"",";")})).join(" ")}(n,r);return document.createTextNode("".concat(i,"{").concat(o,"}"))}function m(t,e,n,r){var o=window.getComputedStyle(t,n),u=o.getPropertyValue("content");if(""!==u&&"none"!==u){var c=i();try{e.className="".concat(e.className," ").concat(c)}catch(t){return}var a=document.createElement("style");a.appendChild(g(c,n,o,r)),e.appendChild(a)}}var w="application/font-woff",y="image/jpeg",b={woff:w,woff2:w,ttf:"application/font-truetype",eot:"application/vnd.ms-fontobject",png:"image/png",jpg:y,jpeg:y,gif:"image/gif",tiff:"image/tiff",svg:"image/svg+xml",webp:"image/webp"};function S(t){var e=function(t){var e=/\.([^./]*?)$/g.exec(t);return e?e[1]:""}(t).toLowerCase();return b[e]||""}function E(t){return-1!==t.search(/^(data:)/)}function x(t,e){return"data:".concat(e,";base64,").concat(t)}function C(t,r,i){return e(this,void 0,void 0,(function(){var e,o;return n(this,(function(n){switch(n.label){case 0:return[4,fetch(t,r)];case 1:if(404===(e=n.sent()).status)throw new Error('Resource "'.concat(e.url,'" not found'));return[4,e.blob()];case 2:return o=n.sent(),[2,new Promise((function(t,n){var r=new FileReader;r.onerror=n,r.onloadend=function(){try{t(i({res:e,result:r.result}))}catch(t){n(t)}},r.readAsDataURL(o)}))]}}))}))}var P={};function R(t,r,i){return e(this,void 0,void 0,(function(){var e,o,u,c,a;return n(this,(function(n){switch(n.label){case 0:if(e=function(t,e,n){var r=t.replace(/\?.*/,"");return n&&(r=t),/ttf|otf|eot|woff2?/i.test(r)&&(r=r.replace(/.*\//,"")),e?"[".concat(e,"]").concat(r):r}(t,r,i.includeQueryParams),null!=P[e])return[2,P[e]];i.cacheBust&&(t+=(/\?/.test(t)?"&":"?")+(new Date).getTime()),n.label=1;case 1:return n.trys.push([1,3,,4]),[4,C(t,i.fetchRequestInit,(function(t){var e=t.res,n=t.result;return r||(r=e.headers.get("Content-Type")||""),function(t){return t.split(/,/)[1]}(n)}))];case 2:return u=n.sent(),o=x(u,r),[3,4];case 3:return c=n.sent(),o=i.imagePlaceholder||"",a="Failed to fetch resource: ".concat(t),c&&(a="string"==typeof c?c:c.message),a&&console.warn(a),[3,4];case 4:return P[e]=o,[2,o]}}))}))}function T(t){return e(this,void 0,void 0,(function(){var e;return n(this,(function(n){return"data:,"===(e=t.toDataURL())?[2,t.cloneNode(!1)]:[2,h(e)]}))}))}function A(t,r){return e(this,void 0,void 0,(function(){var e,i,o,u;return n(this,(function(n){switch(n.label){case 0:return t.currentSrc?(e=document.createElement("canvas"),i=e.getContext("2d"),e.width=t.clientWidth,e.height=t.clientHeight,null==i||i.drawImage(t,0,0,e.width,e.height),[2,h(e.toDataURL())]):(o=t.poster,u=S(o),[4,R(o,u,r)]);case 1:return[2,h(n.sent())]}}))}))}function k(t,r){var i;return e(this,void 0,void 0,(function(){return n(this,(function(e){switch(e.label){case 0:return e.trys.push([0,3,,4]),(null===(i=null==t?void 0:t.contentDocument)||void 0===i?void 0:i.body)?[4,I(t.contentDocument.body,r,!0)]:[3,2];case 1:return[2,e.sent()];case 2:return[3,4];case 3:return e.sent(),[3,4];case 4:return[2,t.cloneNode(!1)]}}))}))}var L=function(t){return null!=t.tagName&&"SVG"===t.tagName.toUpperCase()};function N(t,e,n){return p(e,Element)&&(function(t,e,n){var r=e.style;if(r){var i=window.getComputedStyle(t);i.cssText?(r.cssText=i.cssText,r.transformOrigin=i.transformOrigin):c(n).forEach((function(n){var o=i.getPropertyValue(n);if("font-size"===n&&o.endsWith("px")){var u=Math.floor(parseFloat(o.substring(0,o.length-2)))-.1;o="".concat(u,"px")}p(t,HTMLIFrameElement)&&"display"===n&&"inline"===o&&(o="block"),"d"===n&&e.getAttribute("d")&&(o="path(".concat(e.getAttribute("d"),")")),r.setProperty(n,o,i.getPropertyPriority(n))}))}}(t,e,n),function(t,e,n){m(t,e,":before",n),m(t,e,":after",n)}(t,e,n),function(t,e){p(t,HTMLTextAreaElement)&&(e.innerHTML=t.value),p(t,HTMLInputElement)&&e.setAttribute("value",t.value)}(t,e),function(t,e){if(p(t,HTMLSelectElement)){var n=e,r=Array.from(n.children).find((function(e){return t.value===e.getAttribute("value")}));r&&r.setAttribute("selected","")}}(t,e)),e}function I(t,r,i){return e(this,void 0,void 0,(function(){return n(this,(function(u){return i||!r.filter||r.filter(t)?[2,Promise.resolve(t).then((function(t){return function(t,r){return e(this,void 0,void 0,(function(){return n(this,(function(e){return p(t,HTMLCanvasElement)?[2,T(t)]:p(t,HTMLVideoElement)?[2,A(t,r)]:p(t,HTMLIFrameElement)?[2,k(t,r)]:[2,t.cloneNode(L(t))]}))}))}(t,r)})).then((function(i){return function(t,r,i){var u,c;return e(this,void 0,void 0,(function(){var e;return n(this,(function(n){switch(n.label){case 0:return L(r)?[2,r]:(e=[],0===(e=null!=(a=t).tagName&&"SLOT"===a.tagName.toUpperCase()&&t.assignedNodes?o(t.assignedNodes()):p(t,HTMLIFrameElement)&&(null===(u=t.contentDocument)||void 0===u?void 0:u.body)?o(t.contentDocument.body.childNodes):o((null!==(c=t.shadowRoot)&&void 0!==c?c:t).childNodes)).length||p(t,HTMLVideoElement)?[2,r]:[4,e.reduce((function(t,e){return t.then((function(){return I(e,i)})).then((function(t){t&&r.appendChild(t)}))}),Promise.resolve())]);case 1:return n.sent(),[2,r]}var a}))}))}(t,i,r)})).then((function(e){return N(t,e,r)})).then((function(t){return function(t,r){return e(this,void 0,void 0,(function(){var e,i,o,u,c,a,s,l,f,h,d,v,p;return n(this,(function(n){switch(n.label){case 0:if(0===(e=t.querySelectorAll?t.querySelectorAll("use"):[]).length)return[2,t];i={},p=0,n.label=1;case 1:return p<e.length?(o=e[p],(u=o.getAttribute("xlink:href"))?(c=t.querySelector(u),a=document.querySelector(u),c||!a||i[u]?[3,3]:(s=i,l=u,[4,I(a,r,!0)])):[3,3]):[3,4];case 2:s[l]=n.sent(),n.label=3;case 3:return p++,[3,1];case 4:if((f=Object.values(i)).length){for(h="http://www.w3.org/1999/xhtml",(d=document.createElementNS(h,"svg")).setAttribute("xmlns",h),d.style.position="absolute",d.style.width="0",d.style.height="0",d.style.overflow="hidden",d.style.display="none",v=document.createElementNS(h,"defs"),d.appendChild(v),p=0;p<f.length;p++)v.appendChild(f[p]);t.appendChild(d)}return[2,t]}}))}))}(t,r)}))]:[2,null]}))}))}var D=/url\((['"]?)([^'"]+?)\1\)/g,H=/url\([^)]+\)\s*format\((["']?)([^"']+)\1\)/g,M=/src:\s*(?:url\([^)]+\)\s*format\([^)]+\)[,;]\s*)+/g;function F(t,r,i,o,u){return e(this,void 0,void 0,(function(){var e,c,a,s;return n(this,(function(n){switch(n.label){case 0:return n.trys.push([0,5,,6]),e=i?function(t,e){if(t.match(/^[a-z]+:\/\//i))return t;if(t.match(/^\/\//))return window.location.protocol+t;if(t.match(/^[a-z]+:/i))return t;var n=document.implementation.createHTMLDocument(),r=n.createElement("base"),i=n.createElement("a");return n.head.appendChild(r),n.body.appendChild(i),e&&(r.href=e),i.href=t,i.href}(r,i):r,c=S(r),a=void 0,u?[4,u(e)]:[3,2];case 1:return s=n.sent(),a=x(s,c),[3,4];case 2:return[4,R(e,c,o)];case 3:a=n.sent(),n.label=4;case 4:return[2,t.replace((l=r,f=l.replace(/([.*+?^${}()|\[\]\/\\])/g,"\\$1"),new RegExp("(url\\(['\"]?)(".concat(f,")(['\"]?\\))"),"g")),"$1".concat(a,"$3"))];case 5:return n.sent(),[3,6];case 6:return[2,t]}var l,f}))}))}function V(t){return-1!==t.search(D)}function q(t,r,i){return e(this,void 0,void 0,(function(){var e,o;return n(this,(function(n){return V(t)?(e=function(t,e){var n=e.preferredFontFormat;return n?t.replace(M,(function(t){for(;;){var e=H.exec(t)||[],r=e[0],i=e[2];if(!i)return"";if(i===n)return"src: ".concat(r,";")}})):t}(t,i),o=function(t){var e=[];return t.replace(D,(function(t,n,r){return e.push(r),t})),e.filter((function(t){return!E(t)}))}(e),[2,o.reduce((function(t,e){return t.then((function(t){return F(t,e,r,i)}))}),Promise.resolve(e))]):[2,t]}))}))}function U(t,r,i){var o;return e(this,void 0,void 0,(function(){var e,u;return n(this,(function(n){switch(n.label){case 0:return(e=null===(o=r.style)||void 0===o?void 0:o.getPropertyValue(t))?[4,q(e,null,i)]:[3,2];case 1:return u=n.sent(),r.style.setProperty(t,u,r.style.getPropertyPriority(t)),[2,!0];case 2:return[2,!1]}}))}))}function j(t,r){return e(this,void 0,void 0,(function(){var e,i;return n(this,(function(n){switch(n.label){case 0:return[4,U("background",t,r)];case 1:return n.sent()?[3,3]:[4,U("background-image",t,r)];case 2:n.sent(),n.label=3;case 3:return[4,U("mask",t,r)];case 4:return(i=n.sent())?[3,6]:[4,U("-webkit-mask",t,r)];case 5:i=n.sent(),n.label=6;case 6:return(e=i)?[3,8]:[4,U("mask-image",t,r)];case 7:e=n.sent(),n.label=8;case 8:return e?[3,10]:[4,U("-webkit-mask-image",t,r)];case 9:n.sent(),n.label=10;case 10:return[2]}}))}))}function O(t,r){return e(this,void 0,void 0,(function(){var e,i,o;return n(this,(function(n){switch(n.label){case 0:return(e=p(t,HTMLImageElement))&&!E(t.src)||p(t,SVGImageElement)&&!E(t.href.baseVal)?[4,R(i=e?t.src:t.href.baseVal,S(i),r)]:[2];case 1:return o=n.sent(),[4,new Promise((function(n,i){t.onload=n,t.onerror=r.onImageErrorHandler?function(){for(var t=[],e=0;e<arguments.length;e++)t[e]=arguments[e];try{n(r.onImageErrorHandler.apply(r,t))}catch(t){i(t)}}:i;var u=t;u.decode&&(u.decode=n),"lazy"===u.loading&&(u.loading="eager"),e?(t.srcset="",t.src=o):t.href.baseVal=o}))];case 2:return n.sent(),[2]}}))}))}function B(t,r){return e(this,void 0,void 0,(function(){var e,i;return n(this,(function(n){switch(n.label){case 0:return e=o(t.childNodes),i=e.map((function(t){return z(t,r)})),[4,Promise.all(i).then((function(){return t}))];case 1:return n.sent(),[2]}}))}))}function z(t,r){return e(this,void 0,void 0,(function(){return n(this,(function(e){switch(e.label){case 0:return p(t,Element)?[4,j(t,r)]:[3,4];case 1:return e.sent(),[4,O(t,r)];case 2:return e.sent(),[4,B(t,r)];case 3:e.sent(),e.label=4;case 4:return[2]}}))}))}var W={};function $(t){return e(this,void 0,void 0,(function(){var e,r;return n(this,(function(n){switch(n.label){case 0:return null!=(e=W[t])?[2,e]:[4,fetch(t)];case 1:return[4,n.sent().text()];case 2:return r=n.sent(),e={url:t,cssText:r},W[t]=e,[2,e]}}))}))}function G(t,r){return e(this,void 0,void 0,(function(){var i,o,u,c,a=this;return n(this,(function(s){return i=t.cssText,o=/url\(["']?([^"')]+)["']?\)/g,u=i.match(/url\([^)]+\)/g)||[],c=u.map((function(u){return e(a,void 0,void 0,(function(){var e;return n(this,(function(n){return(e=u.replace(o,"$1")).startsWith("https://")||(e=new URL(e,t.url).href),[2,C(e,r.fetchRequestInit,(function(t){var e=t.result;return i=i.replace(u,"url(".concat(e,")")),[u,e]}))]}))}))})),[2,Promise.all(c).then((function(){return i}))]}))}))}function _(t){if(null==t)return[];for(var e=[],n=t.replace(/(\/\*[\s\S]*?\*\/)/gi,""),r=new RegExp("((@.*?keyframes [\\s\\S]*?){([\\s\\S]*?}\\s*?)})","gi");;){if(null===(u=r.exec(n)))break;e.push(u[0])}n=n.replace(r,"");for(var i=/@import[\s\S]*?url\([^)]*\)[\s\S]*?;/gi,o=new RegExp("((\\s*?(?:\\/\\*[\\s\\S]*?\\*\\/)?\\s*?@media[\\s\\S]*?){([\\s\\S]*?)}\\s*?})|(([\\s\\S]*?){([\\s\\S]*?)})","gi");;){var u;if(null===(u=i.exec(n))){if(null===(u=o.exec(n)))break;i.lastIndex=o.lastIndex}else o.lastIndex=i.lastIndex;e.push(u[0])}return e}function J(t,r){return e(this,void 0,void 0,(function(){var e,i;return n(this,(function(n){return e=[],i=[],t.forEach((function(e){if("cssRules"in e)try{o(e.cssRules||[]).forEach((function(t,n){if(t.type===CSSRule.IMPORT_RULE){var o=n+1,u=$(t.href).then((function(t){return G(t,r)})).then((function(t){return _(t).forEach((function(t){try{e.insertRule(t,t.startsWith("@import")?o+=1:e.cssRules.length)}catch(e){console.error("Error inserting rule from remote css",{rule:t,error:e})}}))})).catch((function(t){console.error("Error loading remote css",t.toString())}));i.push(u)}}))}catch(o){var n=t.find((function(t){return null==t.href}))||document.styleSheets[0];null!=e.href&&i.push($(e.href).then((function(t){return G(t,r)})).then((function(t){return _(t).forEach((function(t){n.insertRule(t,n.cssRules.length)}))})).catch((function(t){console.error("Error loading remote stylesheet",t)}))),console.error("Error inlining remote css file",o)}})),[2,Promise.all(i).then((function(){return t.forEach((function(t){if("cssRules"in t)try{o(t.cssRules||[]).forEach((function(t){e.push(t)}))}catch(e){console.error("Error while reading CSS rules from ".concat(t.href),e)}})),e}))]}))}))}function Q(t){return t.filter((function(t){return t.type===CSSRule.FONT_FACE_RULE})).filter((function(t){return V(t.style.getPropertyValue("src"))}))}function X(t,r){return e(this,void 0,void 0,(function(){return n(this,(function(e){switch(e.label){case 0:if(null==t.ownerDocument)throw new Error("Provided element is not within a Document");return[4,J(o(t.ownerDocument.styleSheets),r)];case 1:return[2,Q(e.sent())]}}))}))}function K(t){return t.trim().replace(/["']/g,"")}function Y(t,r){return e(this,void 0,void 0,(function(){var e,i;return n(this,(function(n){switch(n.label){case 0:return[4,X(t,r)];case 1:return e=n.sent(),i=function(t){var e=new Set;return function t(n){(n.style.fontFamily||getComputedStyle(n).fontFamily).split(",").forEach((function(t){e.add(K(t))})),Array.from(n.children).forEach((function(e){e instanceof HTMLElement&&t(e)}))}(t),e}(t),[4,Promise.all(e.filter((function(t){return i.has(K(t.style.fontFamily))})).map((function(t){var e=t.parentStyleSheet?t.parentStyleSheet.href:null;return q(t.cssText,e,r)})))];case 2:return[2,n.sent().join("\n")]}}))}))}function Z(t,r){return e(this,void 0,void 0,(function(){var e,i,o,u,c;return n(this,(function(n){switch(n.label){case 0:return null==r.fontEmbedCSS?[3,1]:(i=r.fontEmbedCSS,[3,5]);case 1:return r.skipFonts?(o=null,[3,4]):[3,2];case 2:return[4,Y(t,r)];case 3:o=n.sent(),n.label=4;case 4:i=o,n.label=5;case 5:return(e=i)&&(u=document.createElement("style"),c=document.createTextNode(e),u.appendChild(c),t.firstChild?t.insertBefore(u,t.firstChild):t.appendChild(u)),[2]}}))}))}function tt(t,r){return void 0===r&&(r={}),e(this,void 0,void 0,(function(){var e,i,o,u;return n(this,(function(n){switch(n.label){case 0:return e=s(t,r),i=e.width,o=e.height,[4,I(t,r,!0)];case 1:return[4,Z(u=n.sent(),r)];case 2:return n.sent(),[4,z(u,r)];case 3:return n.sent(),function(t,e){var n=t.style;e.backgroundColor&&(n.backgroundColor=e.backgroundColor),e.width&&(n.width="".concat(e.width,"px")),e.height&&(n.height="".concat(e.height,"px"));var r=e.style;null!=r&&Object.keys(r).forEach((function(t){n[t]=r[t]}))}(u,r),[4,v(u,i,o)];case 4:return[2,n.sent()]}}))}))}function et(t,r){return void 0===r&&(r={}),e(this,void 0,void 0,(function(){var e,i,o,u,c,a,f,d,v;return n(this,(function(n){switch(n.label){case 0:return e=s(t,r),i=e.width,o=e.height,[4,tt(t,r)];case 1:return[4,h(n.sent())];case 2:return u=n.sent(),c=document.createElement("canvas"),a=c.getContext("2d"),f=r.pixelRatio||function(){var t,e;try{e=process}catch(t){}var n=e&&e.env?e.env.devicePixelRatio:null;return n&&(t=parseInt(n,10),Number.isNaN(t)&&(t=1)),t||window.devicePixelRatio||1}(),d=r.canvasWidth||i,v=r.canvasHeight||o,c.width=d*f,c.height=v*f,r.skipAutoScale||function(t){(t.width>l||t.height>l)&&(t.width>l&&t.height>l?t.width>t.height?(t.height*=l/t.width,t.width=l):(t.width*=l/t.height,t.height=l):t.width>l?(t.height*=l/t.width,t.width=l):(t.width*=l/t.height,t.height=l))}(c),c.style.width="".concat(d),c.style.height="".concat(v),r.backgroundColor&&(a.fillStyle=r.backgroundColor,a.fillRect(0,0,c.width,c.height)),a.drawImage(u,0,0,c.width,c.height),[2,c]}}))}))}t.getFontEmbedCSS=function(t,r){return void 0===r&&(r={}),e(this,void 0,void 0,(function(){return n(this,(function(e){return[2,Y(t,r)]}))}))},t.toBlob=function(t,r){return void 0===r&&(r={}),e(this,void 0,void 0,(function(){return n(this,(function(e){switch(e.label){case 0:return[4,et(t,r)];case 1:return[4,f(e.sent())];case 2:return[2,e.sent()]}}))}))},t.toCanvas=et,t.toJpeg=function(t,r){return void 0===r&&(r={}),e(this,void 0,void 0,(function(){return n(this,(function(e){switch(e.label){case 0:return[4,et(t,r)];case 1:return[2,e.sent().toDataURL("image/jpeg",r.quality||1)]}}))}))},t.toPixelData=function(t,r){return void 0===r&&(r={}),e(this,void 0,void 0,(function(){var e,i,o,u;return n(this,(function(n){switch(n.label){case 0:return e=s(t,r),i=e.width,o=e.height,[4,et(t,r)];case 1:return u=n.sent(),[2,u.getContext("2d").getImageData(0,0,i,o).data]}}))}))},t.toPng=function(t,r){return void 0===r&&(r={}),e(this,void 0,void 0,(function(){return n(this,(function(e){switch(e.label){case 0:return[4,et(t,r)];case 1:return[2,e.sent().toDataURL()]}}))}))},t.toSvg=tt}));
//# sourceMappingURL=html-to-image.js.map

/**
 * Dev Inspect — standalone embeddable element inspector.
 *
 * Usage:
 *   <script src="https://op.wpmix.net/embed.js"></script>
 *
 * Activation:
 *   - Ctrl+Shift+D (toggle)
 *   - URL param: ?dev_inspect=1
 *   - JS API: window.DevInspect.enable() / .disable() / .toggle()
 *
 * When active:
 *   - Hover highlights elements (orange border)
 *   - Click opens popup with debug info
 *   - "Copy" copies report to clipboard
 *   - "Fix it" opens op.wpmix.net terminal with pre-filled prompt
 */
;(function boot() {
  'use strict';
  if (!document.body) {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
    return;
  }

  if (window.__devInspectLoaded) return;
  window.__devInspectLoaded = true;

  var OP_BASE = 'https://op.wpmix.net';
  var SCRIPT_CWD = (document.currentScript && document.currentScript.getAttribute('data-cwd')) || '';
  var SCRIPT_APP = (document.currentScript && document.currentScript.getAttribute('data-app')) || '';
  var SITE_HOST = window.location.hostname;
  var POPUP_W = 380;
  var MOBILE_BREAKPOINT = 480;
  var BORDER_COLOR = '#FF6B35';
  var Z_TRACKER = 2147483640;
  var Z_POPUP = 2147483641;

  // --- State ---
  var active = false;
  var tracker = null;   // hover highlight div
  var popup = null;      // info popup div
  var lastEl = null;     // last inspected element
  var rafPending = false;
  var locked = false;    // true when element is selected and popup is open
  var termPanel = null;     // inline terminal iframe panel
  var suspendedPanel = null; // suspended stub panel (no iframe)

  // --- Helpers ---
  function qs(sel, root) { return (root || document).querySelector(sel); }

  function isDebugMode() {
    try {
      if (new URLSearchParams(location.search).get('dev_inspect_debug') === '1') return true;
    } catch (_) {}
    try {
      return localStorage.getItem('__devInspectDebug') === '1';
    } catch (_) {}
    return false;
  }

  // Find a scrolled custom div container (pages where window.scrollY is always 0)
  function findScrollContainer() {
    var probe = lastEl;
    while (probe && probe !== document.documentElement) {
      if (probe.scrollTop > 0) return probe;
      probe = probe.parentElement;
    }
    var all = document.querySelectorAll('*');
    for (var i = 0; i < all.length; i++) {
      if (all[i].scrollTop > 0) return all[i];
    }
    return null;
  }

  // Shift children up via transform so html-to-image captures the scrolled position.
  // html-to-image clones DOM (losing scrollTop), but CSS transform is preserved in clone.
  function applyScrollFix(cont) {
    if (!cont || cont.scrollTop === 0) return null;
    var st = cont.scrollTop;
    var kids = Array.from(cont.children);
    var prev = kids.map(function (c) { return c.style.transform; });
    kids.forEach(function (c) {
      c.style.transform = (c.style.transform ? c.style.transform + ' ' : '') + 'translateY(-' + st + 'px)';
    });
    cont.scrollTop = 0;
    return { container: cont, savedScrollTop: st, children: kids, prevTransforms: prev };
  }

  function restoreScrollFix(fix) {
    if (!fix) return;
    fix.children.forEach(function (c, i) { c.style.transform = fix.prevTransforms[i]; });
    fix.container.scrollTop = fix.savedScrollTop;
  }

  function smartSelect(el) {
    if (!el || el === document.body || el === document.documentElement) return document.body;
    var skip = { SVG: 1, SPAN: 1, PATH: 1, BR: 1, I: 1, B: 1, EM: 1, STRONG: 1 };
    var cur = el;
    if (skip[cur.tagName]) cur = cur.parentElement;
    while (cur && cur !== document.body) {
      if (cur.id || cur.getAttribute('data-testid') ||
          (cur.className && typeof cur.className === 'string' && cur.className.trim())) {
        return cur;
      }
      cur = cur.parentElement;
    }
    return document.body;
  }

  function domPath(el) {
    var parts = [];
    var cur = el;
    while (cur && cur !== document.body && cur !== document.documentElement) {
      var sel = (cur.tagName || '').toLowerCase();
      if (cur.id) sel += '#' + cur.id;
      else if (cur.className && typeof cur.className === 'string') {
        var cls = cur.className.trim().split(/\s+/).filter(Boolean).slice(0, 3);
        if (cls.length) sel += '.' + cls.join('.');
      }
      parts.unshift(sel);
      cur = cur.parentElement;
    }
    var full = parts.join(' > ');
    return full.length > 200 ? '\u2026' + full.slice(-200) : full;
  }

  function reactComponent(el) {
    try {
      var keys = Object.keys(el);
      for (var i = 0; i < keys.length; i++) {
        if (keys[i].indexOf('__reactFiber') === 0 || keys[i].indexOf('__reactInternalInstance') === 0) {
          var fiber = el[keys[i]];
          var type = fiber && fiber.type;
          return (type && (type.displayName || type.name)) || null;
        }
      }
    } catch (_) {}
    return null;
  }

  function buildReport(info, comment) {
    return [
      'Dev Inspect Report',
      '',
      SCRIPT_APP ? 'App: ' + SCRIPT_APP : '',
      'Debug info:',
      'URL: ' + location.href,
      'Element: ' + (info.id ? '#' + info.id : info.tag),
      'DOM: ' + info.dom,
      info.text ? 'Text on element: ' + info.text : '',
      'Component: ' + (info.component || 'N/A'),
      'Viewport: ' + window.innerWidth + 'x' + window.innerHeight,
      'Timestamp: ' + new Date().toISOString().replace('T', ' ').replace(/\.\d+Z$/, ''),
      comment ? '\nComment: ' + comment : ''
    ].filter(Boolean).join('\n');
  }

  function loadScreenshotLib(cb) {
    if (window.htmlToImage) { cb(); return; }
    var s = document.createElement('script');
    s.src = OP_BASE + '/html-to-image.js';
    s.onload = function () { cb(); };
    s.onerror = function () { cb(new Error('load failed')); };
    document.head.appendChild(s);
  }

  function screenshotToClipboard(btn, originalHtml) {
    btn.textContent = '...';
    btn.disabled = true;
    loadScreenshotLib(function (err) {
      if (err) {
        btn.innerHTML = 'Error';
        btn.disabled = false;
        return;
      }

      // Apply outline directly to the element — browser places it exactly,
      // no coordinate math needed
      var prevOutline = lastEl ? lastEl.style.outline : '';
      var prevOutlineOffset = lastEl ? lastEl.style.outlineOffset : '';
      if (lastEl) {
        lastEl.style.outline = '3px solid ' + BORDER_COLOR;
        lastEl.style.outlineOffset = '-1px';
      }

      // Hide tracker: it's position:fixed so html-to-image renders it at wrong
      // position after viewport crop (offset by scrollY). Popup stays visible.
      if (tracker) tracker.style.display = 'none';

      var scrollX = window.scrollX || 0;
      var scrollY = window.scrollY || 0;
      var vw = window.innerWidth;
      var vh = window.innerHeight;

      var restore = function () {
        if (lastEl) {
          lastEl.style.outline = prevOutline;
          lastEl.style.outlineOffset = prevOutlineOffset;
        }
        if (tracker) tracker.style.display = 'block';
      };

      var scrollFix = scrollY === 0 ? applyScrollFix(findScrollContainer()) : null;

      window.htmlToImage.toCanvas(document.documentElement, {
        cacheBust: true,
        pixelRatio: 1,
      }).then(function (fullCanvas) {
        restoreScrollFix(scrollFix);
        restore();

        // Crop full-page canvas to current viewport
        var out = document.createElement('canvas');
        out.width = vw;
        out.height = vh;
        var ctx = out.getContext('2d');
        ctx.drawImage(fullCanvas, scrollX, scrollY, vw, vh, 0, 0, vw, vh);

        out.toBlob(function (blob) {
          var done = function () {
            btn.innerHTML = svgCheck + ' Copied!';
            btn.style.background = '#e6f4ea';
            btn.style.borderColor = '#34a853';
            btn.style.color = '#34a853';
            btn.disabled = false;
            setTimeout(function () {
              btn.innerHTML = originalHtml;
              btn.style.background = '#f5f5f5';
              btn.style.borderColor = '#ddd';
              btn.style.color = '#333';
            }, 2000);
          };
          var fallbackDownload = function () {
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = 'screenshot.png';
            document.body.appendChild(a);
            a.click();
            setTimeout(function () { document.body.removeChild(a); URL.revokeObjectURL(url); }, 1000);
            done();
          };
          if (!blob) { btn.innerHTML = originalHtml; btn.disabled = false; return; }
          if (navigator.clipboard && window.ClipboardItem) {
            navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })])
              .then(done).catch(fallbackDownload);
          } else {
            fallbackDownload();
          }
        }, 'image/png');
      }).catch(function (e) {
        restoreScrollFix(scrollFix);
        restore();
        console.error('[DevInspect] screenshot error:', e);
        btn.innerHTML = 'Error';
        btn.disabled = false;
        setTimeout(function () { btn.innerHTML = originalHtml; btn.disabled = false; }, 2000);
      });
    });
  }

  // Upload screenshot via direct fetch (CORS * on /upload endpoint).
  // Falls back to null if CSP blocks connect-src — fails fast, no 15s timeout.
  function uploadScreenshot(dataUrl, cb) {
    fetch(OP_BASE + '/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ image: dataUrl }),
    }).then(function (r) {
      return r.ok ? r.json() : Promise.reject(r.status);
    }).then(function (resp) {
      cb(resp.url || null);
    }).catch(function () {
      cb(null);
    });
  }

  function copyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).catch(function () { fallbackCopy(text); });
    }
    fallbackCopy(text);
  }

  function fallbackCopy(text) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;opacity:0;left:-9999px';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch (_) {}
    document.body.removeChild(ta);
  }

  // Safari requires clipboard writes to happen inside a live user activation.
  // Promise-based ClipboardItem preserves that activation across async work
  // (Safari 13.4+, Chrome 97+). Falls back to a sync copy of the base text.
  function copyTextAsync(textPromise, baseText) {
    if (navigator.clipboard && navigator.clipboard.write && window.ClipboardItem) {
      try {
        var blobPromise = textPromise.then(function (t) {
          return new Blob([t || baseText || ''], { type: 'text/plain' });
        });
        var item = new ClipboardItem({ 'text/plain': blobPromise });
        return navigator.clipboard.write([item]).catch(function () {
          if (baseText) copyText(baseText);
          textPromise.then(function (t) { if (t && t !== baseText) { try { copyText(t); } catch (_) {} } });
        });
      } catch (_) { /* ClipboardItem does not accept Promise here — fall through */ }
    }
    if (baseText) copyText(baseText);
    return textPromise.then(function (t) {
      if (t && t !== baseText) { try { copyText(t); } catch (_) {} }
    });
  }

  // Suspended panel: shows title bar only, no iframe until user clicks Reconnect
  function openSuspendedPanel(url) {
    if (suspendedPanel || termPanel) return;

    var W = Math.min(320, window.innerWidth - 40);
    var left = window.innerWidth - W - 20;
    var top = window.innerHeight - 36 - 20;

    var panel = document.createElement('div');
    panel.setAttribute('data-dev-inspect', 'terminal-panel');
    panel.style.cssText = 'position:fixed;left:' + left + 'px;top:' + top + 'px;' +
      'width:' + W + 'px;z-index:' + (Z_PANEL || 2147483638) + ';' +
      'display:flex;flex-direction:column;' +
      'background:#252526;border-radius:8px 8px 8px 8px;' +
      'box-shadow:0 -2px 16px rgba(0,0,0,.4);overflow:hidden;';

    var bar = document.createElement('div');
    bar.style.cssText = 'display:flex;align-items:center;justify-content:space-between;' +
      'padding:0 10px;height:32px;flex-shrink:0;cursor:default;' +
      'font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",monospace;font-size:12px;color:#aaa;' +
      'user-select:none;';

    var titleEl = document.createElement('span');
    titleEl.textContent = '\u2b1b Terminal \u2014 suspended';
    titleEl.style.cssText = 'opacity:0.6;';

    var btns = document.createElement('div');
    btns.style.cssText = 'display:flex;gap:6px;';

    var btnReconnect = document.createElement('button');
    btnReconnect.textContent = '\u21ba Reconnect';
    btnReconnect.title = 'Reconnect to terminal session';
    btnReconnect.style.cssText = 'background:#2d5a27;border:none;color:#7ec975;cursor:pointer;' +
      'font-size:11px;padding:2px 8px;border-radius:3px;';
    btnReconnect.addEventListener('mouseenter', function () { btnReconnect.style.background = '#3a7533'; });
    btnReconnect.addEventListener('mouseleave', function () { btnReconnect.style.background = '#2d5a27'; });
    btnReconnect.addEventListener('click', function () {
      panel.remove();
      suspendedPanel = null;
      openTerminalPanel(url);
    });

    var btnDiscard = document.createElement('button');
    btnDiscard.textContent = '\u00d7';
    btnDiscard.title = 'Discard session';
    btnDiscard.style.cssText = 'background:none;border:none;color:#aaa;cursor:pointer;font-size:13px;padding:1px 6px;border-radius:3px;';
    btnDiscard.addEventListener('mouseenter', function () { btnDiscard.style.background = '#c0392b'; });
    btnDiscard.addEventListener('mouseleave', function () { btnDiscard.style.background = 'none'; });
    btnDiscard.addEventListener('click', function () {
      panel.remove();
      suspendedPanel = null;
      try { localStorage.removeItem('__devTerminalUrl'); } catch (_) {}
    });

    btns.appendChild(btnReconnect);
    btns.appendChild(btnDiscard);
    bar.appendChild(titleEl);
    bar.appendChild(btns);
    panel.appendChild(bar);
    document.body.appendChild(panel);
    suspendedPanel = panel;
  }

  // --- Terminal Panel (floating iframe) ---
  var Z_PANEL = 2147483638; // below popup/tracker

  function openTerminalPanel(url) {
    // Remove suspended stub if present
    if (suspendedPanel) { suspendedPanel.remove(); suspendedPanel = null; }
    if (termPanel) {
      var ifrm = termPanel.querySelector('iframe');
      if (ifrm) ifrm.src = url;
      termPanel.style.display = 'flex';
      return;
    }

    var W = Math.min(680, window.innerWidth - 40);
    var H = Math.min(480, window.innerHeight - 60);
    var left = window.innerWidth - W - 20;
    var top = window.innerHeight - H - 20;

    try {
      var u = new URL(url);
      u.searchParams.delete('prompt');
      localStorage.setItem('__devTerminalUrl', u.toString());
    } catch (_) {}

    var panel = document.createElement('div');
    panel.setAttribute('data-dev-inspect', 'terminal-panel');
    panel.style.cssText = 'position:fixed;left:' + left + 'px;top:' + top + 'px;' +
      'width:' + W + 'px;height:' + H + 'px;z-index:' + Z_PANEL + ';' +
      'display:flex;flex-direction:column;' +
      'background:#1e1e1e;border-radius:8px 8px 0 0;' +
      'box-shadow:0 -4px 32px rgba(0,0,0,.5);overflow:hidden;';

    // Titlebar (drag handle)
    var bar = document.createElement('div');
    bar.style.cssText = 'display:flex;align-items:center;justify-content:space-between;' +
      'padding:0 10px;height:32px;background:#252526;flex-shrink:0;cursor:move;' +
      'font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",monospace;font-size:12px;color:#aaa;' +
      'user-select:none;';

    var titleEl = document.createElement('span');
    titleEl.textContent = '\u2b1b Terminal';

    var btns = document.createElement('div');
    btns.style.cssText = 'display:flex;gap:6px;';

    function mkBtn(label, title) {
      var b = document.createElement('button');
      b.textContent = label;
      b.title = title;
      b.style.cssText = 'background:none;border:none;color:#aaa;cursor:pointer;' +
        'font-size:13px;padding:1px 6px;border-radius:3px;line-height:1;';
      b.addEventListener('mouseenter', function () { b.style.background = '#3c3c3c'; });
      b.addEventListener('mouseleave', function () { b.style.background = 'none'; });
      return b;
    }

    var btnPop = mkBtn('\u29c9', 'Open in new window');
    btnPop.addEventListener('click', function () { window.open(url, '_blank', 'noopener,noreferrer'); });

    var btnMin = mkBtn('\u2012', 'Minimize');
    var minimized = false;
    var savedH = H;
    btnMin.addEventListener('click', function () {
      minimized = !minimized;
      if (minimized) {
        savedH = panel.offsetHeight;
        panel.style.height = '32px';
        panel.querySelector('iframe').style.display = 'none';
      } else {
        panel.style.height = savedH + 'px';
        panel.querySelector('iframe').style.display = 'block';
      }
    });

    var btnClose = mkBtn('\u00d7', 'Close');
    btnClose.addEventListener('mouseenter', function () { btnClose.style.background = '#c0392b'; });
    btnClose.addEventListener('click', function () {
      panel.remove();
      termPanel = null;
      try { localStorage.removeItem('__devTerminalUrl'); } catch (_) {}
    });

    btns.appendChild(btnPop);
    btns.appendChild(btnMin);
    btns.appendChild(btnClose);
    bar.appendChild(titleEl);
    bar.appendChild(btns);

    // Iframe
    var iframe = document.createElement('iframe');
    iframe.src = url;
    iframe.style.cssText = 'flex:1;border:none;width:100%;display:block;';
    iframe.allow = 'clipboard-read; clipboard-write';

    // Resize handle (bottom-right corner)
    var resizeHandle = document.createElement('div');
    resizeHandle.style.cssText = 'position:absolute;bottom:0;right:0;width:14px;height:14px;cursor:nwse-resize;' +
      'background:linear-gradient(135deg,transparent 50%,#555 50%);';

    panel.appendChild(bar);
    panel.appendChild(iframe);
    panel.appendChild(resizeHandle);
    document.body.appendChild(panel);
    termPanel = panel;

    // CSP fallback: if iframe is blocked by host site's CSP, open in new window
    function onCspViolation(e) {
      var blocked = e.blockedURI || '';
      if (blocked && url.indexOf(blocked.split('?')[0]) === 0) {
        document.removeEventListener('securitypolicyviolation', onCspViolation);
        panel.remove();
        termPanel = null;
        window.open(url, '_blank', 'noopener,noreferrer');
      }
    }
    document.addEventListener('securitypolicyviolation', onCspViolation);
    setTimeout(function () { document.removeEventListener('securitypolicyviolation', onCspViolation); }, 3000);

    // Drag (move)
    var dragState = { active: false, ox: 0, oy: 0 };
    bar.addEventListener('mousedown', function (e) {
      if (e.target.tagName === 'BUTTON') return;
      dragState.active = true;
      dragState.ox = e.clientX - panel.offsetLeft;
      dragState.oy = e.clientY - panel.offsetTop;
      e.preventDefault();
    });

    // Resize
    var resizeState = { active: false, ox: 0, oy: 0, ow: 0, oh: 0 };
    resizeHandle.addEventListener('mousedown', function (e) {
      resizeState.active = true;
      resizeState.ox = e.clientX;
      resizeState.oy = e.clientY;
      resizeState.ow = panel.offsetWidth;
      resizeState.oh = panel.offsetHeight;
      e.preventDefault();
      e.stopPropagation();
    });

    document.addEventListener('mousemove', function (e) {
      if (dragState.active) {
        var nx = e.clientX - dragState.ox;
        var ny = e.clientY - dragState.oy;
        nx = Math.max(0, Math.min(window.innerWidth - panel.offsetWidth, nx));
        ny = Math.max(0, Math.min(window.innerHeight - 32, ny));
        panel.style.left = nx + 'px';
        panel.style.top = ny + 'px';
      }
      if (resizeState.active && !minimized) {
        var nw = Math.max(320, resizeState.ow + (e.clientX - resizeState.ox));
        var nh = Math.max(120, resizeState.oh + (e.clientY - resizeState.oy));
        panel.style.width = nw + 'px';
        panel.style.height = nh + 'px';
      }
    });

    document.addEventListener('mouseup', function () {
      dragState.active = false;
      resizeState.active = false;
    });
  }

  // --- UI Creation ---
  function createTracker() {
    var el = document.createElement('div');
    el.setAttribute('data-dev-inspect', 'tracker');
    el.style.cssText = 'position:fixed;pointer-events:none;border:2px solid ' + BORDER_COLOR +
      ';z-index:' + Z_TRACKER + ';display:none;box-sizing:border-box;border-radius:2px;' +
      'transition:top .05s,left .05s,width .05s,height .05s;';
    document.body.appendChild(el);
    return el;
  }

  function isMobile() {
    return window.innerWidth <= MOBILE_BREAKPOINT;
  }

  function makeDraggable(el, handle) {
    handle.addEventListener('mousedown', function (e) {
      if (e.button !== 0) return;
      e.preventDefault();
      e.stopPropagation();
      var rect = el.getBoundingClientRect();
      el.style.transform = 'none';
      el.style.right = 'auto';
      el.style.bottom = 'auto';
      el.style.left = rect.left + 'px';
      el.style.top = rect.top + 'px';
      el._dragged = true;
      var ox = e.clientX - rect.left;
      var oy = e.clientY - rect.top;
      function onMove(ev) {
        var x = Math.max(0, Math.min(window.innerWidth - el.offsetWidth, ev.clientX - ox));
        var y = Math.max(0, Math.min(window.innerHeight - el.offsetHeight, ev.clientY - oy));
        el.style.left = x + 'px';
        el.style.top = y + 'px';
      }
      function onUp() {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
      }
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });
  }

  function positionPopup(anchorEl) {
    if (!popup) return;
    if (popup._dragged) return;
    if (isMobile()) {
      // Bottom sheet mode
      popup.style.left = '0';
      popup.style.right = '0';
      popup.style.bottom = '0';
      popup.style.top = 'auto';
      popup.style.width = '100%';
      popup.style.maxWidth = '100%';
      popup.style.borderRadius = '14px 14px 0 0';
      popup.style.maxHeight = '70vh';
      popup.style.overflowY = 'auto';
      return;
    }
    if (!anchorEl || !anchorEl.getBoundingClientRect) return;
    popup.style.right = 'auto';
    popup.style.bottom = 'auto';
    popup.style.width = POPUP_W + 'px';
    popup.style.maxWidth = '';
    popup.style.borderRadius = '10px';
    popup.style.maxHeight = '';
    popup.style.overflowY = '';
    var rect = anchorEl.getBoundingClientRect();
    var x = rect.right + 10;
    var y = rect.top;
    if (x + POPUP_W > window.innerWidth) x = rect.left - POPUP_W - 10;
    if (x < 8) x = 8;
    var ph = popup.offsetHeight || 300;
    if (y + ph > window.innerHeight) y = window.innerHeight - ph - 8;
    if (y < 8) y = 8;
    popup.style.left = x + 'px';
    popup.style.top = y + 'px';
  }

  function showPopup(info) {
    if (popup) popup.remove();

    popup = document.createElement('div');
    popup.setAttribute('data-dev-inspect', 'popup');
    var mobile = isMobile();
    popup.style.cssText = 'position:fixed;z-index:' + Z_POPUP +
      ';background:#fff;border:1px solid #ddd;border-radius:10px;' +
      'box-shadow:0 8px 32px rgba(0,0,0,.18);padding:' + (mobile ? '20px 16px' : '16px') +
      ';font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;' +
      'font-size:' + (mobile ? '14px' : '13px') + ';color:#1f1f1f;' +
      'box-sizing:border-box;width:' + POPUP_W + 'px;';

    var html = '<style>.di-agent-row{display:flex;align-items:center;gap:10px;margin-bottom:4px}.di-agent-row label{display:flex;align-items:center;gap:4px;cursor:pointer;font-size:12px;color:#333;line-height:1}.di-agent-row input[type=radio]{width:13px;height:13px;margin:0;padding:0;flex-shrink:0;cursor:pointer;vertical-align:middle;position:relative;top:0}</style>' +
    '<div data-dev-inspect="drag" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;cursor:move;user-select:none">' +
      '<b style="font-size:14px">Code review</b>' +
      '<button data-action="close" style="background:none;border:none;cursor:pointer;color:#999;font-size:18px;padding:0 4px" title="Close">&times;</button>' +
      '</div>';

    if (SCRIPT_CWD) html += row('Folder', '<code style="font-size:11px">' + esc(SCRIPT_CWD) + '</code>');
    if (info.text) html += row('Text on element', '<span style="font-size:11px;color:#555;word-break:break-word">' + esc(info.text) + '</span>');
    if (isDebugMode()) {
      html += row('DOM', '<span style="font-size:11px;word-break:break-all">' + esc(info.dom) + '</span>');
    }
    if (info.component) html += row('Component', '<code>' + esc(info.component) + '</code>');

    // Comment
    var btnPad = mobile ? '12px 0' : '7px 0';
    var btnFont = mobile ? '14px' : '12px';
    html += '<textarea data-ref="comment" placeholder="Comment..." style="width:100%;height:50px;border:1px solid #ddd;border-radius:' + (mobile ? '8px' : '4px') + ';padding:8px;font-size:' + (mobile ? '16px' : '12px') + ';resize:vertical;box-sizing:border-box;margin:8px 0;font-family:inherit"></textarea>';

    // Agent selector — hidden inside collapsible "Advanced settings"
    html += '<details style="margin-bottom:6px">' +
      '<summary style="font-size:11px;color:#aaa;cursor:pointer;list-style:none;outline:none;user-select:none;display:flex;align-items:center;gap:4px">' +
        '<span style="font-size:9px">▶</span> Advanced settings' +
      '</summary>' +
      '<div class="di-agent-row" style="margin-top:4px">' +
        '<label><input type="radio" name="di-agent" value="claude">' + svgClaude + 'Claude</label>' +
        '<label><input type="radio" name="di-agent" value="codex">' + svgCodex + 'Codex</label>' +
      '</div>' +
      '<div data-ref="claude-hint" style="display:none;font-size:10px;color:#999;margin-top:2px;padding-left:2px">' +
        '⚠️ may require sign-in with your Claude account' +
      '</div>' +
    '</details>';

    // Buttons row
    html += '<div style="display:flex;gap:8px">';
    html += '<button data-action="copy" style="flex:1;padding:' + btnPad + ';background:#f5f5f5;border:1px solid #ddd;border-radius:' + (mobile ? '8px' : '5px') + ';cursor:pointer;font-size:' + btnFont + ';color:#333;display:flex;align-items:center;justify-content:center;gap:4px">' +
      svgCopy + ' Copy debug info</button>';
    html += '<button data-action="fix" style="flex:1;padding:' + btnPad + ';background:#FF6B35;border:none;border-radius:' + (mobile ? '8px' : '5px') + ';cursor:pointer;font-size:' + btnFont + ';color:#fff;display:flex;align-items:center;justify-content:center;gap:4px;font-weight:500">' +
      svgTerminal + ' Fix it</button>';
    html += '</div>';

    popup.innerHTML = html;
    document.body.appendChild(popup);
    makeDraggable(popup, popup.querySelector('[data-dev-inspect="drag"]'));

    // Init agent selector from localStorage
    var agentInputs = popup.querySelectorAll('[name="di-agent"]');
    var claudeHint = popup.querySelector('[data-ref="claude-hint"]');
    var defaultAgent = (window.__simpleReviewSource === 'extension') ? 'codex' : 'claude';
    var storedAgent = defaultAgent;
    try { storedAgent = localStorage.getItem('__devInspectAgent') || defaultAgent; } catch (_) {}
    for (var ai = 0; ai < agentInputs.length; ai++) {
      if (agentInputs[ai].value === storedAgent) agentInputs[ai].checked = true;
    }
    function updateClaudeHint(agent) {
      if (claudeHint) {
        claudeHint.style.display = (window.__simpleReviewSource === 'extension' && agent === 'claude') ? 'block' : 'none';
      }
    }
    updateClaudeHint(storedAgent);
    popup.addEventListener('change', function (e) {
      if (e.target.name === 'di-agent') {
        try { localStorage.setItem('__devInspectAgent', e.target.value); } catch (_) {}
        updateClaudeHint(e.target.value);
      }
    });

    // Events
    popup.addEventListener('click', function (e) {
      var action = e.target.closest('[data-action]');
      if (!action) return;
      e.stopPropagation();
      var act = action.getAttribute('data-action');
      var commentEl = qs('[data-ref="comment"]', popup);
      var comment = commentEl ? commentEl.value : '';

      if (act === 'close') {
        disable();
      } else if (act === 'copy') {
        var origCopyHtml = action.innerHTML;
        var baseReport = buildReport(info, comment);
        var withShot = function (url) {
          return url
            ? baseReport + '\n\n(Before starting, analyze this screenshot — look for visual issues, layout problems, or anything visible that needs to be fixed.)\nScreenshot: ' + url
            : baseReport;
        };

        // Capture screenshot + upload as a Promise that resolves with URL or null.
        var screenshotPromise = new Promise(function (resolve) {
          loadScreenshotLib(function (cpErr) {
            if (cpErr) { resolve(null); return; }
            var cpPrevOutline = lastEl ? lastEl.style.outline : '';
            var cpPrevOutlineOffset = lastEl ? lastEl.style.outlineOffset : '';
            if (lastEl) { lastEl.style.outline = '3px solid ' + BORDER_COLOR; lastEl.style.outlineOffset = '-1px'; }
            if (tracker) tracker.style.display = 'none';
            var cpScrollX = window.scrollX || 0, cpScrollY = window.scrollY || 0;
            var cpVw = window.innerWidth, cpVh = window.innerHeight;
            var cpScrollFix = cpScrollY === 0 ? applyScrollFix(findScrollContainer()) : null;
            setTimeout(function () {
              window.htmlToImage.toCanvas(document.documentElement, { cacheBust: true, pixelRatio: 1 })
                .then(function (cpCanvas) {
                  restoreScrollFix(cpScrollFix);
                  if (lastEl) { lastEl.style.outline = cpPrevOutline; lastEl.style.outlineOffset = cpPrevOutlineOffset; }
                  if (tracker) tracker.style.display = 'block';
                  var cpOut = document.createElement('canvas');
                  cpOut.width = cpVw; cpOut.height = cpVh;
                  cpOut.getContext('2d').drawImage(cpCanvas, cpScrollX, cpScrollY, cpVw, cpVh, 0, 0, cpVw, cpVh);
                  var cpDataUrl = cpOut.toDataURL('image/jpeg', 0.7);
                  uploadScreenshot(cpDataUrl, function (url) { resolve(url || null); });
                })
                .catch(function () {
                  restoreScrollFix(cpScrollFix);
                  if (lastEl) { lastEl.style.outline = cpPrevOutline; lastEl.style.outlineOffset = cpPrevOutlineOffset; }
                  if (tracker) tracker.style.display = 'block';
                  resolve(null);
                });
            }, 0);
          });
        });

        // Kick off clipboard write INSIDE the click handler (user activation live).
        // Promise-based ClipboardItem preserves activation until screenshotPromise
        // resolves; fallback path copies baseReport synchronously so Safari still
        // gets something in the clipboard even if the async path fails.
        copyTextAsync(screenshotPromise.then(withShot), baseReport);

        // Visual feedback — flip to "Copied!" immediately; screenshot keeps
        // uploading in the background and the final clipboard contents include
        // the URL once uploaded.
        action.innerHTML = svgCheck + ' Copied!';
        action.style.background = '#e6f4ea';
        action.style.borderColor = '#34a853';
        action.style.color = '#34a853';
        setTimeout(function () {
          action.innerHTML = origCopyHtml;
          action.style.background = '#f5f5f5';
          action.style.borderColor = '#ddd';
          action.style.color = '#333';
        }, 2000);
      } else if (act === 'fix') {
        var fixBtn = action;
        fixBtn.disabled = true;
        fixBtn.textContent = '...';

        // Read selected agent
        var selectedAgent = (window.__simpleReviewSource === 'extension') ? 'codex' : 'claude';
        var agentEls = popup.querySelectorAll('[name="di-agent"]');
        for (var ai2 = 0; ai2 < agentEls.length; ai2++) {
          if (agentEls[ai2].checked) { selectedAgent = agentEls[ai2].value; break; }
        }

        function launchFix(screenshotUrl) {
          var report = buildReport(info, comment);
          if (screenshotUrl) {
            report += '\n\n(Before starting, analyze this screenshot — look for visual issues, layout problems, or anything visible that needs to be fixed.)\nScreenshot: ' + screenshotUrl;
          }
          report += '\n\nPlease investigate this element and fix any issues.';
          var termUrl = OP_BASE + '/?prompt=' + encodeURIComponent(report) +
            (SCRIPT_CWD ? '&cwd=' + encodeURIComponent(SCRIPT_CWD) : '') +
            (SCRIPT_APP ? '&app=' + encodeURIComponent(SCRIPT_APP) : '') +
            '&host=' + encodeURIComponent(SITE_HOST) +
            '&agent=' + encodeURIComponent(selectedAgent);
          openTerminalPanel(termUrl);
          closePopup();
          disableInspect();
        }

        // Take screenshot and upload, then launch
        fixBtn.textContent = '\uD83D\uDCF8...';
        loadScreenshotLib(function (err) {
          if (err) { console.warn('[DevInspect] screenshot lib failed:', err); launchFix(null); return; }

          fixBtn.textContent = '\u23F3 screenshot';
          var prevOutline = lastEl ? lastEl.style.outline : '';
          var prevOutlineOffset = lastEl ? lastEl.style.outlineOffset : '';
          if (lastEl) {
            lastEl.style.outline = '3px solid ' + BORDER_COLOR;
            lastEl.style.outlineOffset = '-1px';
          }
          if (tracker) tracker.style.display = 'none';

          var scrollX = window.scrollX || 0, scrollY = window.scrollY || 0;
          var vw = window.innerWidth, vh = window.innerHeight;
          var fixScrollFix = scrollY === 0 ? applyScrollFix(findScrollContainer()) : null;

          window.htmlToImage.toCanvas(document.documentElement, { cacheBust: true, pixelRatio: 1 })
            .then(function (fullCanvas) {
              restoreScrollFix(fixScrollFix);
              if (lastEl) { lastEl.style.outline = prevOutline; lastEl.style.outlineOffset = prevOutlineOffset; }
              if (tracker) tracker.style.display = 'block';

              var out = document.createElement('canvas');
              out.width = vw; out.height = vh;
              out.getContext('2d').drawImage(fullCanvas, scrollX, scrollY, vw, vh, 0, 0, vw, vh);

              var dataUrl = out.toDataURL('image/jpeg', 0.7);
              fixBtn.textContent = '\u2B06 uploading';
              uploadScreenshot(dataUrl, function (url) {
                launchFix(url);
              });
            })
            .catch(function (e) {
              restoreScrollFix(fixScrollFix);
              if (lastEl) { lastEl.style.outline = prevOutline; lastEl.style.outlineOffset = prevOutlineOffset; }
              if (tracker) tracker.style.display = 'block';
              console.warn('[DevInspect] toCanvas failed:', e);
              launchFix(null);
            });
        });
      }
    });
  }

  function row(label, value) {
    return '<div style="margin-bottom:6px"><span style="color:#888;font-size:11px">' +
      label + ':</span> ' + value + '</div>';
  }

  function esc(s) {
    var d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
  }

  function closePopup() {
    if (popup) { popup.remove(); popup = null; }
    lastEl = null;
    locked = false;
  }

  function showHint() {
    if (popup) popup.remove();
    popup = document.createElement('div');
    popup.setAttribute('data-dev-inspect', 'popup');
    var mobile = isMobile();
    popup.style.cssText = 'position:fixed;z-index:' + Z_POPUP +
      ';background:#fff;border:1px solid #ddd;border-radius:' + (mobile ? '14px 14px 0 0' : '10px') +
      ';box-shadow:0 8px 32px rgba(0,0,0,.18);padding:' + (mobile ? '24px 20px' : '20px 24px') +
      ';font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#1f1f1f;' +
      'box-sizing:border-box;text-align:center;' +
      (mobile
        ? 'left:0;right:0;bottom:0;top:auto;width:100%;max-width:100%;'
        : 'left:50%;top:50%;transform:translate(-50%,-50%);max-width:340px;');

    popup.innerHTML =
      '<div data-dev-inspect="drag" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;cursor:move;user-select:none">' +
        '<b style="font-size:14px">Code review</b>' +
        '<button data-action="close" style="background:none;border:none;cursor:pointer;color:#999;font-size:18px;padding:0 4px" title="Close">&times;</button>' +
      '</div>' +
      '<div style="font-size:40px;margin-bottom:8px">&#128269;</div>' +
      '<div style="font-size:' + (mobile ? '16px' : '15px') + ';font-weight:500;margin-bottom:6px">Inspect mode is on</div>' +
      '<div style="font-size:' + (mobile ? '14px' : '13px') + ';color:#666">' +
        (mobile ? 'Tap any element on the page' : 'Click any element on the page') +
      '</div>';

    document.body.appendChild(popup);
    makeDraggable(popup, popup.querySelector('[data-dev-inspect="drag"]'));

    popup.addEventListener('click', function (e) {
      var action = e.target.closest('[data-action]');
      if (action && action.getAttribute('data-action') === 'close') {
        e.stopPropagation();
        disable();
      }
    });
  }

  // SVG icons (inline, tiny)
  var svgClaude = '<svg width="13" height="13" viewBox="0 0 24 24" style="flex-shrink:0;display:block"><circle cx="12" cy="12" r="12" fill="#D97706"/><path d="M16 8.5a6 6 0 1 1-8 8.7" stroke="white" stroke-width="2.5" fill="none" stroke-linecap="round"/><circle cx="12" cy="12" r="2" fill="white"/></svg>';
  var svgCodex = '<svg width="13" height="13" viewBox="0 0 24 24" style="flex-shrink:0;display:block"><circle cx="12" cy="12" r="12" fill="#10a37f"/><path d="M12 6v12M6 12h12M7.8 7.8l8.4 8.4M16.2 7.8l-8.4 8.4" stroke="white" stroke-width="2" stroke-linecap="round"/></svg>';
  var svgCopy ='<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>';
  var svgCheck = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>';
  var svgTerminal = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/></svg>';

  // --- Event handlers ---
  function onMouseOver(e) {
    if (!active || !tracker || locked) return;
    if (e.target.closest('[data-dev-inspect]')) return;
    if (rafPending) return;
    rafPending = true;
    requestAnimationFrame(function () {
      var el = smartSelect(e.target);
      if (el && el.getBoundingClientRect) {
        var r = el.getBoundingClientRect();
        tracker.style.top = r.top + 'px';
        tracker.style.left = r.left + 'px';
        tracker.style.width = r.width + 'px';
        tracker.style.height = r.height + 'px';
        tracker.style.display = 'block';
      }
      rafPending = false;
    });
  }

  function inspectElement(target) {
    var el = smartSelect(target);
    lastEl = el;
    locked = true;
    var rect = el.getBoundingClientRect();

    var rawText = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
    var info = {
      id: el.id || null,
      tag: (el.tagName || '').toLowerCase(),
      dom: domPath(el),
      component: reactComponent(el),
      rect: rect,
      text: rawText.length > 120 ? rawText.slice(0, 120) + '\u2026' : rawText
    };

    showPopup(info);
    positionPopup(el);
  }

  function onClick(e) {
    if (!active) return;
    if (e.target.closest('[data-dev-inspect]')) return;
    if (e.ctrlKey) return; // Ctrl+click passes through to the element
    e.preventDefault();
    e.stopPropagation();
    inspectElement(e.target);
  }

  // Touch: first tap highlights, second tap on same element opens popup
  var touchTarget = null;
  function onTouchStart(e) {
    if (!active) return;
    if (e.target.closest('[data-dev-inspect]')) return;
    e.preventDefault();
    var el = smartSelect(e.target);
    if (touchTarget === el) {
      // Second tap — open popup
      inspectElement(e.target);
      touchTarget = null;
      return;
    }
    // First tap — highlight, close hint
    touchTarget = el;
    closePopup();
    if (el && el.getBoundingClientRect && tracker) {
      var r = el.getBoundingClientRect();
      tracker.style.top = r.top + 'px';
      tracker.style.left = r.left + 'px';
      tracker.style.width = r.width + 'px';
      tracker.style.height = r.height + 'px';
      tracker.style.display = 'block';
    }
  }

  function onKeyDown(e) {
    // Ctrl+Shift+D — toggle
    if (e.ctrlKey && e.shiftKey && e.key === 'D') {
      e.preventDefault();
      toggle();
    }
    // Escape — close popup
    if (e.key === 'Escape' && popup) {
      closePopup();
    }
  }

  function onScroll() {
    if (popup && lastEl) positionPopup(lastEl);
  }

  // --- Public API ---
  function enable() {
    if (active) return;
    active = true;
    if (tracker) { tracker.remove(); tracker = null; } // remove frozen highlight if any
    tracker = createTracker();
    document.body.style.cursor = 'crosshair';
    document.addEventListener('mouseover', onMouseOver);
    document.addEventListener('click', onClick, true);
    document.addEventListener('touchstart', onTouchStart, true);
    window.addEventListener('scroll', onScroll);
    window.addEventListener('resize', onScroll);
    showHint();
    try { localStorage.setItem('__devInspect', '1'); } catch (_) {}
  }

  // Disable inspect mode — remove tracker entirely (no frozen highlight)
  function disableInspect() {
    if (!active) return;
    active = false;
    document.body.style.cursor = '';
    document.removeEventListener('mouseover', onMouseOver);
    document.removeEventListener('click', onClick, true);
    document.removeEventListener('touchstart', onTouchStart, true);
    window.removeEventListener('scroll', onScroll);
    window.removeEventListener('resize', onScroll);
    touchTarget = null;
    locked = false;
    if (tracker) { tracker.remove(); tracker = null; }
    try { localStorage.removeItem('__devInspect'); } catch (_) {}
  }

  function disable() {
    if (!active) return;
    active = false;
    document.body.style.cursor = '';
    document.removeEventListener('mouseover', onMouseOver);
    document.removeEventListener('click', onClick, true);
    document.removeEventListener('touchstart', onTouchStart, true);
    window.removeEventListener('scroll', onScroll);
    window.removeEventListener('resize', onScroll);
    touchTarget = null;
    if (tracker) { tracker.remove(); tracker = null; }
    closePopup();
    try { localStorage.removeItem('__devInspect'); } catch (_) {}
  }

  function toggle() {
    active ? disable() : enable();
  }

  // --- Init ---
  document.addEventListener('keydown', onKeyDown);

  // Toggle via click on [data-dev-toggle] (e.g. © in footer)
  document.addEventListener('click', function (e) {
    var el = e.target.closest('[data-dev-toggle]');
    if (el) {
      e.preventDefault();
      e.stopPropagation();
      toggle();
    }
  });

  // Responsive corner button size via injected style
  (function () {
    var s = document.createElement('style');
    s.textContent = '[data-dev-inspect="corner"]{width:22px;height:22px}' +
      '@media(max-width:' + MOBILE_BREAKPOINT + 'px){[data-dev-inspect="corner"]{width:36px;height:36px}}' +
      '[data-dev-inspect] details>summary::-webkit-details-marker{display:none}';
    document.head.appendChild(s);
  })();

  // Invisible corner button (top-right, single click/tap to toggle)
  var cornerBtn = document.createElement('div');
  cornerBtn.setAttribute('data-dev-inspect', 'corner');
  cornerBtn.style.cssText = 'position:fixed;top:0;right:0;z-index:' +
    Z_POPUP + ';cursor:pointer;-webkit-tap-highlight-color:transparent;' +
    'transition:background .2s;border-bottom-left-radius:6px;';
  cornerBtn.addEventListener('mouseenter', function () {
    cornerBtn.style.background = 'rgba(255,107,53,0.18)';
  });
  cornerBtn.addEventListener('mouseleave', function () {
    cornerBtn.style.background = 'transparent';
  });
  cornerBtn.addEventListener('click', function (e) {
    e.preventDefault();
    e.stopPropagation();
    toggle();
  });
  document.body.appendChild(cornerBtn);

  // Auto-enable from URL param or localStorage
  var params = new URLSearchParams(location.search);
  if (params.get('dev_inspect_debug') === '1') {
    try { localStorage.setItem('__devInspectDebug', '1'); } catch (_) {}
  } else if (params.get('dev_inspect_debug') === '0') {
    try { localStorage.removeItem('__devInspectDebug'); } catch (_) {}
  }
  if (params.get('dev_inspect') === '1') {
    // Clean URL
    params.delete('dev_inspect');
    var clean = params.toString();
    history.replaceState(null, '', location.pathname + (clean ? '?' + clean : '') + location.hash);
    enable();
  } else {
    try {
      if (localStorage.getItem('__devInspect') === '1') enable();
    } catch (_) {}
  }

  // Restore terminal panel after page reload — suspended (no iframe until user clicks Reconnect)
  try {
    var savedTermUrl = localStorage.getItem('__devTerminalUrl');
    if (savedTermUrl) openSuspendedPanel(savedTermUrl);
  } catch (_) {}

  // Expose API
  window.DevInspect = { enable: enable, disable: disable, toggle: toggle };
})();
