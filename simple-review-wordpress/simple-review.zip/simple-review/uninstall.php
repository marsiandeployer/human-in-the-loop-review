<?php
/**
 * Uninstall cleanup for SimpleReview.
 *
 * Runs when the plugin is deleted from the WordPress admin. Removes
 * the plugin option so no residual data is left behind.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

delete_option( 'simple_review_settings' );
